function img = findFiles(casePath,option)
%Image load with some pre-processing
%   img = findFiles(casePath,option)
%   casePath: file location. will load every image in this path
%   option: some pre-processing options, e.g.
%               downsample - downsample the image to its half size.
%               aligncrop -first roughly align the image using a glaobal homography and crop the images to the shared region of all images.  

curPath = pwd;
cd(casePath);
list = dir();
names = {list(~[list.isdir]).name};
[t, idx] = sort(names);
names = names(idx);
img = cell(1,length(names));
for i = 1: length(names)
    img{i} = imread(names{i});
end
cd(curPath);

if strcmp(option.imtype,'gray') == true
    for i = 1: length(names)
        img{i} = rgb2gray(img{i});
    end
end

if option.downsample == true
    for i = 1: length(names)
        img{i}=imresize(imfilter(img{i},fspecial('gaussian',7,1.),'same','replicate'),0.5,'bicubic');
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if option.aligncrop == true
    addpath('Sift');
    addpath(genpath('MatlabFns'));
    ref = 1;
    refImg = img{ref};
    sz = size(refImg);
    warp{ref}.img = refImg;
    warp{ref}.r = [1 sz(1)];
    warp{ref}.c = [1 sz(2)];
    rmin = 1;
    rmax = sz(1);
    cmin = 1;
    cmax = sz(2);

    cnrPt      =     [ 1, 1;
                               1, sz(1);
                             sz(2), sz(1);
                             sz(2), 1]';
    for i = 2:length(names)
        img2 = img{i};
        [x1,x2] = match(refImg , img2);
        [H, inliers] = ransacfithomography(x2, x1, 0.001);   %x1 = H*x2
        T = maketform('projective',H');
        xp = round(getProjectedPos(H, cnrPt));
        [r o1 o2] = imtransform(img2,T,'XYScale',1) ;
        warp{i}.img = r;
        warp{i}.r = [round(o2(1)) round(o2(2))];
        warp{i}.c = [round(o1(1)) round(o1(2))];
        rmin = max([rmin, xp(1,1),xp(1,4)]);
        rmax = min([rmax, xp(1,3),xp(1,2)]);
        cmin = max([cmin, xp(2,1),xp(2,2)]);
        cmax = min([cmax, xp(2,3),xp(2,4)]);
    end

    rlim = round([rmin rmax]);
    clim = round([cmin cmax]);
    canvas = cell(1,length(names));

    for i = 1:length(names)
    canvas{i} = zeros( rmax-rmin+1,cmax-cmin+1,3);
    canvas{i} = warp{i}.img(rmin-warp{i}.r(1)+1:rmax-warp{i}.r(1)+1,cmin-warp{i}.c(1)+1:cmax-warp{i}.c(1)+1,:);
    end
    img = canvas;
end

if option.datatype == 'double'
    for i = 1: length(names)
        img{i} = im2double(img{i});
    end
end
end


function xp = getProjectedPos(H, x1)
x1 = [x1; ones(1,size(x1,2))];
x = H*x1;
x = bsxfun(@rdivide,x,x(3,:));
xp = x([2,1],:);
end
