
***************************************************************************************
** Demo code for "Nighttime Haze Removal with Glow and Multiple Light Colors" (ICCV 2015)
** by Yu Li (liyu@nus.edu.sg)
***************************************************************************************


We will be happy to see that you cite our paper if you use our code or data in your work. 



This code also includes:


- Guided Image Filtering:
http://research.microsoft.com/en-us/um/people/kahe/eccv10/

***************************************************************************************
***************************************************************************************
 