
***************************************************************************************
** Demo code for "A Contrast Enhancement Framework with JPEG Artifacts Suppression" (ECCV 2014)
** by Yu Li (liyu@nus.edu.sg)
***************************************************************************************

