I = im2double(imread('1.jpg')); 
[H W D] = size(I);
[LB LR] = septRelSmo(I,50,zeros(H,W,D),I);
figure,subplot 131, imshow(I);
subplot 132, imshow(LB*2);
subplot 133, imshow(LR*2);
